
import streamlit as st
import pandas as pd
import numpy as np
from datetime import datetime, timedelta
import matplotlib.pyplot as plt
import seaborn as sns
import asyncio

# === Sabitler ===
KWH_TO_TL_RATE = 2.5
CARBON_EMISSION_FACTOR_PER_KWH = 0.45

# === VERİ OLUŞTURMA ===
device_specs = {
    'Buzdolabı': {'brands': ['Arçelik', 'Beko', 'Bosch', 'Samsung'], 'avg_hourly_kwh': {'Arçelik': 0.12, 'Beko': 0.11, 'Bosch': 0.13, 'Samsung': 0.14}},
    'Klima': {'brands': ['Mitsubishi', 'Samsung', 'Arçelik', 'Vestel'], 'avg_hourly_kwh': {'Mitsubishi': 2.5, 'Samsung': 2.8, 'Arçelik': 2.6, 'Vestel': 2.4}},
    'Fırın': {'brands': ['Arçelik', 'Bosch', 'Siemens', 'Vestel'], 'avg_hourly_kwh': {'Arçelik': 1.8, 'Bosch': 2.0, 'Siemens': 1.9, 'Vestel': 1.7}}
}

np.random.seed(42)
data = []
for device, specs in device_specs.items():
    for brand in specs['brands']:
        for _ in range(10):
            usage_hours = np.random.uniform(1, 10)
            consumption = usage_hours * specs['avg_hourly_kwh'][brand] * np.random.uniform(0.9, 1.1)
            data.append([device, brand, usage_hours, consumption])

df_device_data = pd.DataFrame(data, columns=['Cihaz', 'Marka', 'Kullanım_süresi_saat', 'Tüketim_kWh'])

start_date = datetime(2023, 1, 1)
dates = [start_date + timedelta(days=i) for i in range(730)]
temp_vals = (15 + 15 * np.sin(np.linspace(0, 4 * np.pi, 730))).round(1)
base_kwh = 15
total_kwh = []

for i, date in enumerate(dates):
    weekday = date.weekday()
    temp = temp_vals[i]
    temp_effect = 0
    if temp < 10:
        temp_effect = (10 - temp) * 0.8
    elif temp > 25:
        temp_effect = (temp - 25) * 1.2
    if weekday >= 5:
        temp_effect += base_kwh * 0.15
    noise = np.random.normal(0, 2)
    daily = base_kwh + temp_effect + noise
    total_kwh.append(max(0, daily))

df_time_series = pd.DataFrame({
    'ds': dates,
    'temperature': temp_vals,
    'y': total_kwh
})
df_time_series['weekday'] = df_time_series['ds'].dt.day_name()

# === Streamlit Ayarlar ===
st.set_page_config(layout="wide")
st.title("🔌 Geleceğin Evi: Gerçek Zamanlı Enerji Dashboard")

# === Sidebar ===
st.sidebar.header("🔍 Filtreler")
cihazlar = sorted(df_device_data["Cihaz"].unique())
selected_device = st.sidebar.selectbox("Cihaz Tipi", cihazlar)
markalar = df_device_data[df_device_data["Cihaz"] == selected_device]["Marka"].unique()
selected_brand = st.sidebar.selectbox("Marka", sorted(markalar))
usage_hours = st.sidebar.slider("Kullanım Süreti (saat)", 1.0, 10.0, 5.0, 0.5)

device_kwh = device_specs[selected_device]['avg_hourly_kwh'][selected_brand]
estimated_kwh = usage_hours * device_kwh
carbon_footprint = round(estimated_kwh * CARBON_EMISSION_FACTOR_PER_KWH, 2)
ecological_footprint = round(carbon_footprint * 0.6, 2)

# === Enerji Verimliliği Skoru ===
score = int(max(0, 100 - (estimated_kwh * 10)))  # Basit ölçekleme

st.sidebar.markdown(f"💨 **Karbon Ayak İzi:** {carbon_footprint} kg CO₂e")
st.sidebar.markdown(f"🌍 **Ekolojik Ayak İzi:** {ecological_footprint} m²")
st.sidebar.markdown(f"⚡ **Enerji Verimliliği Skoru:** {score}/100")

# === Grafikler ===
filtered_df = df_device_data[(df_device_data["Cihaz"] == selected_device) & (df_device_data["Marka"] == selected_brand)]

col1, col2 = st.columns(2)

with col1:
    st.subheader("🌡️ Sıcaklık vs Tüketim")
    fig1, ax1 = plt.subplots()
    sns.scatterplot(data=df_time_series, x="temperature", y="y", ax=ax1)
    sns.regplot(data=df_time_series, x="temperature", y="y", scatter=False, color="red", ax=ax1)
    st.pyplot(fig1)

with col2:
    st.subheader("🗓️ Haftalık Tüketim")
    fig2, ax2 = plt.subplots()
    sns.boxplot(data=df_time_series, x='weekday', y='y',
                order=["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"], ax=ax2)
    st.pyplot(fig2)

st.subheader("📈 Günlük Enerji Tüketimi")
fig3, ax3 = plt.subplots(figsize=(12, 4))
sns.lineplot(data=df_time_series, x="ds", y="y", ax=ax3)
st.pyplot(fig3)

# === Chatbot Simülasyonu ===
st.subheader("🧠 Enerji Asistanı (Chatbot)")
user_prompt = st.text_input("Bir soru sorun (örn. 'Dün ne kadar enerji harcadım?')")

async def query_llm_for_energy_insights(user_prompt):
    p = user_prompt.lower()
    anomaly_detected = np.random.rand() < 0.2
    waste_kwh = np.random.uniform(3, 10) if anomaly_detected else 0
    energy = {
        "yesterday_kwh": df_time_series['y'].iloc[-1].round(2),
        "last_week_avg_kwh": df_time_series['y'].tail(7).mean().round(2),
        "anomaly_detected": anomaly_detected,
        "simulated_waste_kwh": round(waste_kwh, 2),
        "monetary_loss_tl": round(waste_kwh * KWH_TO_TL_RATE, 2),
        "most_consuming_device": "Klima",
        "klima_brand": "Arçelik",
        "klima_avg_kwh_per_hour": 2.6,
        "possible_savings_kwh": round(df_time_series['y'].mean() * 0.15, 2),
        "current_carbon_footprint_kgco2e": round(df_time_series['y'].iloc[-1] * CARBON_EMISSION_FACTOR_PER_KWH, 2)
    }
    if "dün" in p:
        return f"Dün {energy['yesterday_kwh']} kWh tükettiniz. Haftalık ortalama {energy['last_week_avg_kwh']} kWh."
    elif "cihaz" in p:
        return f"En çok tüketim yapan cihaz: {energy['most_consuming_device']} ({energy['klima_brand']}) - {energy['klima_avg_kwh_per_hour']} kWh/saat."
    elif "tasarruf" in p:
        return f"Yaklaşık {energy['possible_savings_kwh']} kWh tasarruf edebilirsiniz."
    elif "israf" in p or "zarar" in p:
        if energy['monetary_loss_tl'] > 0:
            return f"Anomali tespit edildi! Tahmini kaybınız: {energy['monetary_loss_tl']} TL."
        else:
            return "Anormal bir durum tespit edilmedi."
    elif "karbon" in p:
        return f"Dünkü karbon ayak iziniz: {energy['current_carbon_footprint_kgco2e']} kg CO2e."
    else:
        return "Daha fazla bilgi için daha net sorular sorabilirsiniz."

if user_prompt:
    with st.spinner("Yanıt getiriliyor..."):
        response = asyncio.run(query_llm_for_energy_insights(user_prompt))
        st.success(response)
